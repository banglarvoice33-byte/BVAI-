import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const maybeSingle = vi.fn();
const rpc = vi.fn();
const readiness = vi.hoisted(() => vi.fn());

function chain() {
  const c: Record<string, unknown> = {};
  c.select = () => c;
  c.eq = () => c;
  c.in = () => c;
  c.gte = () => c;
  c.not = () => c;
  c.lt = () => c;
  c.order = () => c;
  c.limit = () => c;
  c.update = () => c;
  c.maybeSingle = maybeSingle;
  return c;
}

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({ from: () => chain(), rpc }),
}));

vi.mock('../lib/social-platforms', () => ({
  fetchReadiness: readiness,
  dhakaDayStartIso: () => '2026-10-28T00:00:00.000Z',
  rateLimitReason: () => null,
  ineligibleReason: () => null,
}));

describe('POST /api/social/dispatch', () => {
  beforeEach(() => {
    vi.resetModules();
    maybeSingle.mockReset();
    rpc.mockReset();
    readiness.mockReset();
    readiness.mockResolvedValue({ ready: [], limits: {}, degraded: true });
    process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://example.supabase.co';
    process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-role';
    process.env.SOCIAL_AUTOMATION_ENABLED = 'true';
  });

  afterEach(() => {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;
    delete process.env.SOCIAL_AUTOMATION_ENABLED;
  });

  async function post(headers: Record<string, string> = {}) {
    const { POST } = await import('../app/api/social/dispatch/route');
    return POST(
      new Request('https://example.com/api/social/dispatch', { method: 'POST', headers }),
    );
  }

  it('returns 401 when no cron secret is configured', async () => {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;
    const res = await post();
    expect(res.status).toBe(401);
    expect(await res.json()).toEqual({ error: 'unauthorized' });
  });

  it('honours the SOCIAL_AUTOMATION_ENABLED kill switch', async () => {
    maybeSingle.mockResolvedValue({ data: { key_encrypted: 'vault-ref' } });
    rpc.mockResolvedValue({ data: 'test-secret' });
    process.env.SOCIAL_AUTOMATION_ENABLED = 'false';
    const res = await post({ Authorization: 'Bearer test-secret' });
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true, processed: 0, disabled: true });
  });

  it('keeps social posting off when the opt-in flag is absent', async () => {
    maybeSingle.mockResolvedValue({ data: { key_encrypted: 'vault-ref' } });
    rpc.mockResolvedValue({ data: 'test-secret' });
    delete process.env.SOCIAL_AUTOMATION_ENABLED;
    const res = await post({ Authorization: 'Bearer test-secret' });
    expect(await res.json()).toEqual({ ok: true, processed: 0, disabled: true });
    expect(readiness).not.toHaveBeenCalled();
  });

  it('fails closed when readiness is unreadable', async () => {
    maybeSingle.mockResolvedValue({ data: { key_encrypted: 'vault-ref' } });
    rpc.mockResolvedValue({ data: 'test-secret' });
    const res = await post({ Authorization: 'Bearer test-secret' });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.processed).toBe(0);
    expect(body.ready).toBe(0);
    expect(body.degraded).toBe(true);
    expect(body.reason).toBe('no_ready_platforms');
  });

  it('fails closed when the atomic claim RPC is unavailable', async () => {
    maybeSingle.mockResolvedValue({ data: { key_encrypted: 'vault-ref' } });
    readiness.mockResolvedValue({
      ready: ['facebook'],
      limits: { facebook: { daily: 12, minGapMinutes: 45 } },
      degraded: false,
    });
    rpc.mockImplementation((name: string) => {
      if (name === 'decrypt_vault_secret') return Promise.resolve({ data: 'test-secret' });
      return Promise.resolve({ data: null, error: { message: 'function not found' } });
    });
    const res = await post({ Authorization: 'Bearer test-secret' });
    expect(res.status).toBe(503);
    expect(await res.json()).toEqual({ error: 'queue_claim_failed' });
    expect(rpc).toHaveBeenCalledWith('claim_social_posts', {
      p_platforms: ['facebook'],
      p_limit: 40,
      p_lease_seconds: 900,
    });
  });
});
