-- Additive Nov-10 patch. Existing data and live schedules remain intact.
-- Register new gate inactive; explicit activation SQL switches the scheduler owner.
BEGIN;
CREATE OR REPLACE FUNCTION public.heartbeat_reviewed_render(p_job_id uuid,p_claim_token uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 UPDATE public.video_generation_jobs SET lease_expires_at=now()+interval '25 minutes',updated_at=now()
 WHERE id=p_job_id AND claim_token=p_claim_token AND status='processing' AND lease_expires_at>now();
 IF NOT FOUND THEN RAISE EXCEPTION 'render_fence_lost'; END IF;
 RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.heartbeat_reviewed_render(uuid,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.heartbeat_reviewed_render(uuid,uuid) TO service_role;

CREATE TABLE IF NOT EXISTS public.newsroom_cadence_state (
 id boolean PRIMARY KEY DEFAULT true CHECK(id),
 last_requested_at timestamptz,
 last_request_id bigint,
 previous_jobs jsonb NOT NULL DEFAULT '[]'::jsonb
);
INSERT INTO public.newsroom_cadence_state(id) VALUES(true) ON CONFLICT DO NOTHING;
ALTER TABLE public.newsroom_cadence_state ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.newsroom_cadence_state FROM PUBLIC,anon,authenticated;
GRANT ALL ON public.newsroom_cadence_state TO service_role;
DROP POLICY IF EXISTS service_only ON public.newsroom_cadence_state;
CREATE POLICY service_only ON public.newsroom_cadence_state FOR ALL TO service_role USING(true) WITH CHECK(true);

CREATE OR REPLACE FUNCTION public.tick_newsroom_14m()
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE last_tick timestamptz; secret text; origin text; request_id bigint;
BEGIN
 IF NOT pg_catalog.pg_try_advisory_xact_lock(73920514) THEN RETURN NULL; END IF;
 SELECT last_requested_at INTO last_tick FROM public.newsroom_cadence_state WHERE id=true FOR UPDATE;
 IF last_tick IS NOT NULL AND now()<last_tick+interval '14 minutes' THEN RETURN NULL; END IF;
 SELECT ds.decrypted_secret INTO secret FROM public.api_vault v JOIN vault.decrypted_secrets ds ON ds.id=v.key_encrypted
 WHERE v.service_name='NEWSROOM_INGEST_KEY' AND v.environment='prod' AND v.is_active LIMIT 1;
 origin:=rtrim(public.deployment_setting('SITE_URL'),'/');
 IF length(COALESCE(secret,''))<32 OR origin !~ '^https://[a-zA-Z0-9.-]+(:443)?$' THEN RAISE EXCEPTION 'cadence_configuration_missing'; END IF;
 SELECT net.http_post(url:=origin||'/api/newsroom/cron-trigger',headers:=jsonb_build_object('Content-Type','application/json','Authorization','Bearer '||secret),body:='{}'::jsonb,timeout_milliseconds:=90000) INTO request_id;
 IF request_id IS NULL THEN RAISE EXCEPTION 'cadence_enqueue_failed'; END IF;
 UPDATE public.newsroom_cadence_state SET last_requested_at=now(),last_request_id=request_id WHERE id=true;
 -- This is a request receipt, never a claim that an article was published.
 RETURN request_id;
END $$;
REVOKE ALL ON FUNCTION public.tick_newsroom_14m() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tick_newsroom_14m() TO service_role;
DO $$ DECLARE job bigint; BEGIN
 IF to_regclass('cron.job') IS NOT NULL THEN
  IF NOT EXISTS(SELECT 1 FROM cron.job WHERE jobname='bvai-newsroom-14m') THEN
   SELECT cron.schedule('bvai-newsroom-14m','* * * * *','select public.tick_newsroom_14m();') INTO job;
   PERFORM cron.alter_job(job,active:=false);
  END IF;
 END IF;
END $$;
CREATE OR REPLACE FUNCTION public.finalize_media_delivery(
  p_job_id uuid,p_article_id uuid,p_claim_token uuid,p_path text,p_signed_url text,
  p_duration_sec integer,p_sha256 text,p_size_bytes bigint,p_publish boolean,
  p_manifest jsonb,p_targets jsonb DEFAULT '[]'::jsonb
) RETURNS TABLE(video_id uuid,job_status text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_id uuid; v_status text; target jsonb; a public.articles%ROWTYPE; j public.video_generation_jobs%ROWTYPE;
BEGIN
  IF p_publish IS NULL OR p_path IS NULL OR p_signed_url IS NULL OR p_duration_sec IS NULL OR p_duration_sec<40 OR p_duration_sec>120 OR p_sha256 IS NULL OR p_size_bytes IS NULL OR p_manifest IS NULL OR p_targets IS NULL THEN RAISE EXCEPTION 'invalid_media_contract'; END IF;
  IF jsonb_typeof(p_targets)<>'array' OR jsonb_array_length(p_targets)>4 THEN RAISE EXCEPTION 'invalid_delivery_targets'; END IF;
  SELECT * INTO j FROM public.video_generation_jobs WHERE id=p_job_id AND article_id=p_article_id FOR UPDATE;
  IF NOT FOUND OR j.claim_token IS DISTINCT FROM p_claim_token THEN RAISE EXCEPTION 'media_claim_mismatch'; END IF;
  IF j.status='processing' AND (j.lease_expires_at IS NULL OR j.lease_expires_at<=now()) THEN RAISE EXCEPTION 'media_lease_expired'; END IF;
  IF NOT EXISTS(SELECT 1 FROM public.video_story_reservations WHERE job_id=p_job_id AND script_hash=p_manifest->>'script_hash' AND content_key=p_manifest->>'content_key') THEN RAISE EXCEPTION 'missing_story_reservation'; END IF;
  SELECT * INTO a FROM public.articles WHERE id=p_article_id;
  IF p_publish AND (a.human_verified IS DISTINCT FROM true OR a.verification_status IS DISTINCT FROM 'verified') THEN RAISE EXCEPTION 'editorial_verification_required'; END IF;
  IF p_publish AND (a.source_published_at IS NULL OR a.source_published_at<now()-interval '24 hours' OR a.source_published_at>now()+interval '5 minutes') THEN RAISE EXCEPTION 'primary_source_stale'; END IF;
  IF p_publish AND (jsonb_typeof(p_manifest->'evidence') IS DISTINCT FROM 'array' OR (SELECT count(*) FROM jsonb_array_elements(p_manifest->'evidence') e WHERE e->>'role'='news_source' AND e->>'sha256' ~ '^[a-f0-9]{64}$' AND (e->>'fetched_at')::timestamptz>now()-interval '24 hours')<2) THEN RAISE EXCEPTION 'fresh_evidence_required'; END IF;
  IF NOT p_publish AND jsonb_array_length(p_targets)>0 THEN RAISE EXCEPTION 'review_cannot_distribute'; END IF;
  IF p_manifest->>'caption_method' NOT IN ('groq-whisper','edge-matched') OR p_manifest->>'caption_method' IS NULL THEN RAISE EXCEPTION 'actual_audio_captions_required'; END IF;
  -- Strip worker claim credentials and local filesystem paths from stored manifest.
  SELECT f.video_id,f.job_status INTO v_id,v_status FROM public.finalize_website_video(p_job_id,p_article_id,p_claim_token,p_path,p_signed_url,p_duration_sec,p_sha256,p_size_bytes,p_publish) f;
  INSERT INTO public.video_delivery_assets(video_id,job_id,sha256,manifest)
  VALUES(v_id,p_job_id,p_sha256,p_manifest-'claim_token'-'video_path')
  ON CONFLICT ON CONSTRAINT video_delivery_assets_pkey DO UPDATE SET manifest=EXCLUDED.manifest WHERE video_delivery_assets.sha256=EXCLUDED.sha256;
  IF NOT EXISTS(SELECT 1 FROM public.video_delivery_assets WHERE video_delivery_assets.video_id=v_id AND sha256=p_sha256) THEN RAISE EXCEPTION 'asset_replay_mismatch'; END IF;
  -- Keep complete rights/source attribution visible on the website as well as social descriptions.
  UPDATE public.videos SET description_bn=COALESCE(a.content_bn,'') || E'\n\nসূত্র:\n' ||
    COALESCE((SELECT string_agg(e->>'url',E'\n') FROM jsonb_array_elements(COALESCE(p_manifest->'evidence','[]'::jsonb)) e WHERE e->>'role'='news_source' AND e ? 'sha256'),'') || E'\n\nপ্রতীকী দৃশ্য — উৎস ও লাইসেন্স:\n' ||
    COALESCE((SELECT string_agg(concat_ws(' | ',m->>'author',m->>'license',m->>'source_url',m->>'license_url'),E'\n') FROM jsonb_array_elements(COALESCE(p_manifest->'media','[]'::jsonb)) m),'')
  WHERE videos.id=v_id;
  IF p_publish THEN
    -- articles.video_id is legacy external-YouTube TEXT, not public.videos UUID.
    -- Do not corrupt that semantic contract by writing a local UUID into it.
    UPDATE public.articles SET video_generated=true,video_generated_at=COALESCE(video_generated_at,now()),updated_at=now() WHERE id=p_article_id;
    FOR target IN SELECT value FROM jsonb_array_elements(p_targets) LOOP
      INSERT INTO public.video_delivery_outbox(video_id,platform,account_id)
      VALUES(v_id,target->>'platform',target->>'account_id') ON CONFLICT ON CONSTRAINT video_delivery_outbox_video_id_platform_account_id_key DO NOTHING;
    END LOOP;
  END IF;
  RETURN QUERY SELECT v_id,v_status;
END $$;


COMMIT;
