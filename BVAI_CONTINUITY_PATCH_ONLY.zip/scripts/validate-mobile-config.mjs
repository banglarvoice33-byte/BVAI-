import fs from 'node:fs';
const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const allowed=new Set(['SUPABASE_URL','SUPABASE_ANON_KEY','API_BASE','BV_API_BASE','BV_AI_PROCESS_URL','BV_AI_ENDLIVE_URL','BV_AI_LIVE_WS','BV_AI_CLIP_URL','BV_LIVEKIT_URL','BV_RTMP_INGEST','BV_LIVE_YOUTUBE_ID']);
if(Object.keys(config).some(k=>!allowed.has(k)))throw new Error('Only explicitly public mobile config keys are allowed');
if(Object.keys(config).some(k=>/SECRET|SERVICE_ROLE|REFRESH_TOKEN|ACCESS_TOKEN|PRIVATE_KEY/.test(k)))throw new Error('Server-only credential forbidden in mobile build');
for(const key of ['SUPABASE_URL','SUPABASE_ANON_KEY','API_BASE'])if(!config[key])throw new Error('Missing mobile config '+key);
for(const key of ['SUPABASE_URL','API_BASE'])if(new URL(config[key]).protocol!=='https:')throw new Error('Production HTTPS required');
const anon=config.SUPABASE_ANON_KEY;
if(anon.startsWith('eyJ')) {
 const payload=JSON.parse(Buffer.from(anon.split('.')[1],'base64url'));
 if(payload.role!=='anon')throw new Error('Only anon JWT allowed in APK');
} else if(!anon.startsWith('sb_publishable_'))throw new Error('Only Supabase publishable/anon key allowed');
console.log('Mobile configuration validated; no credential values printed');
