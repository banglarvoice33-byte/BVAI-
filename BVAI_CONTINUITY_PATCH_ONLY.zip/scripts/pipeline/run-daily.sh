#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
if [[ $# -gt 0 ]]; then echo 'Legacy --public/--unlisted flags retired; use explicit VIDEO_PUBLISH_MODE and ARTICLE_ID'; exit 2; fi
exec bash "$ROOT/run-bvai.sh"
