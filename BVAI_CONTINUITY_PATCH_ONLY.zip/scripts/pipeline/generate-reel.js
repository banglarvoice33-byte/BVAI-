// Retired standalone publisher: unified pipeline owns claims, rights and delivery.
console.error('Legacy generate-reel is retired. Use bash run-bvai.sh with VIDEO_PUBLISH_MODE=review|website|distribute.');
process.exitCode=2;
