import {loadVaultEnv} from './load-vault-env.mjs';
import {createClient} from '@supabase/supabase-js';
const groups={youtube:['YOUTUBE_CHANNEL_ID','OAUTH_CLIENT_ID','OAUTH_CLIENT_SECRET','YOUTUBE_REFRESH_TOKEN'],facebook:['SOCIAL_FACEBOOK_PAGE_ID','SOCIAL_FACEBOOK_PAGE_TOKEN'],instagram:['SOCIAL_INSTAGRAM_BUSINESS_ACCOUNT_ID','SOCIAL_INSTAGRAM_ACCESS_TOKEN'],tiktok:['TIKTOK_CLIENT_KEY','TIKTOK_CLIENT_SECRET','TIKTOK_ACCESS_TOKEN','TIKTOK_OPEN_ID']};
await loadVaultEnv();
const report={credentials:{},database:{},notice:'Presence only, not provider authorization or delivery proof. No provider contacted.'};
for(const [platform,names] of Object.entries(groups))report.credentials[platform]={present:names.filter(n=>!!process.env[n]),missing:names.filter(n=>!process.env[n])};
if(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) {
 const db=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false}});
 for(const table of ['videos','video_generation_jobs','video_delivery_outbox','video_story_reservations','video_visual_reservations']) {
  const {count,error}=await db.from(table).select('*',{count:'exact',head:true});report.database[table]=error?{ok:false,code:error.code}:{ok:true,count};
 }
} else report.database.error='Supabase URL/service role missing';
console.log(JSON.stringify(report,null,2));
if(Object.values(report.database).some(x=>x?.ok===false) || report.database.error)process.exitCode=1;
