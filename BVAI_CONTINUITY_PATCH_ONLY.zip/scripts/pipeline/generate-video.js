import {createClient} from '@supabase/supabase-js';
import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {synthesizeVoice} from './voice-captions.js';
import {loadVaultEnv} from './load-vault-env.mjs';
import {assertEditorial,refreshEvidence,nearDuplicate} from './source-evidence.mjs';
import {collectSceneMedia} from './scene-media.mjs';
import {fingerprint,compareFingerprint} from './quality-v3/media-qc.mjs';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const TMP=path.resolve(__dirname,'../../temp_assets');
const hash=x=>createHash('sha256').update(x).digest('hex');
export function buildVoiceScript(article,{brandFree=false}={}) {
  const clean=s=>String(s || '').normalize('NFC').replace(/<[^>]*>/g,' ').replace(/https?:\/\/\S+/g,'').replace(/\s+/g,' ').trim();
  const title=clean(article.title_bn);
  const body=clean(article.content_bn).split(/সূত্র\s*:/)[0].trim();
  const sentences=body.match(/[^।!?]+[।!?]/gu) || [];
  const selected=[];let size=title.length;
  for(const sentence of sentences) {
    if(size+sentence.length>1080)break;
    selected.push(sentence.trim());size+=sentence.length+1;
  }
  if(!title || !selected.length)throw new Error('No complete source sentences fit narration; editor must shorten source');
  // Extractive only. Never invent reactions, consequences, or today's dateline.
  return [title.replace(/[।!?]+$/u,''),...selected,...(brandFree?[]:['বিস্তারিত দেখুন বাংলার ভয়েস ওয়েবসাইটে।'])].join('। ').replace(/[।]\s*[।]/gu,'।').replace(/[0-9]/g,d=>'০১২৩৪৫৬৭৮৯'[Number(d)]);
}
function visualLen(s) {
  if (typeof Intl !== 'undefined' && Intl.Segmenter) {
    try {
      const seg = new Intl.Segmenter('bn', { granularity: 'grapheme' });
      return [...seg.segment(s)].length;
    } catch (_) {}
  }
  return [...String(s).normalize('NFC')].length;
}

function wrapTitle(title, maxLen = 22, maxLines = 3) {
  const words = String(title || '').trim().split(/\s+/);
  const lines = [];
  let line = '';
  for (const w of words) {
    const c = line ? line + ' ' + w : w;
    if (visualLen(c) > maxLen && line) {
      lines.push(line);
      line = w;
      if (lines.length === maxLines) break;
    } else line = c;
  }
  if (line && lines.length < maxLines) lines.push(line);
  return lines.length ? lines : [String(title || '')];
}

export function renderOverlay(title, outPath,{brandFree=false}={}) {
  const esc = (s) => String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
  const lines = wrapTitle(title);
  const font = "'Noto Sans Bengali','Hind Siliguri','Lohit Bengali','SolaimanLipi',sans-serif";
  const boxTop = 180;
  const boxH = 200 + lines.length * 62;
  const tspans = lines.map((l, i) =>
    '<tspan x="90" dy="' + (i === 0 ? 0 : 62) + '">' + esc(l) + '</tspan>'
  ).join('');
  const svg = '<?xml version="1.0" encoding="UTF-8"?>\n' +
    '<svg width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">' +
    '<rect x="50" y="' + boxTop + '" width="980" height="' + boxH + '" rx="20" fill="#000" fill-opacity="0.85"/>' +
    '<text x="90" y="' + (boxTop + 50) + '" font-family="' + font + '" font-size="34" font-weight="bold" fill="#FF1744">' + (brandFree ? 'সংবাদ আপডেট' : 'বাংলার ভয়েস | সংবাদ আপডেট') + '</text>' +
    '<text x="90" y="' + (boxTop + 110) + '" font-family="' + font + '" font-size="44" font-weight="bold" fill="#FFFFFF">' + tspans + '</text>' +
    '<text x="80" y="1600" font-family="' + font + '" font-size="30" fill="#FFFFFF">প্রতীকী দৃশ্য | সূত্র ও ক্রেডিট বিবরণে</text>' +
    '</svg>';
  const svgPath = outPath.replace(/\.png$/i, '.svg');
  fs.writeFileSync(svgPath, svg, 'utf8');
  try {
    execFileSync('rsvg-convert', ['-f', 'png', '-o', outPath, svgPath], { timeout: 60000 });
    console.log('   ✅ rsvg-convert OK');
  } catch (e) {
    console.log('   ⚠️  rsvg-convert failed → ffmpeg fallback');
    execFileSync('ffmpeg', ['-y', '-i', svgPath, outPath], { timeout: 60000, stdio: 'inherit' });
  }
}

export function composeVideo(images, audioPath, subPath, overlayPath, outPath) {
  const audioDur = Number(execFileSync('ffprobe', [
    '-v','error','-show_entries','format=duration',
    '-of','default=noprint_wrappers=1:nokey=1', audioPath
  ]).toString().trim());
  if (!Number.isFinite(audioDur) || audioDur < 38.75 || audioDur > 118.75) throw new Error('Narration must fit a 40–120 second master; do not pad or cut speech');

  const totalDur = Math.ceil((audioDur + 1.25) * 100) / 100;
  const per = totalDur / images.length;
  const args = [];
  for (const img of images) {
    if (/\.mp4$/i.test(img)) args.push('-stream_loop','-1','-t',per.toFixed(3),'-i',img);
    else args.push('-loop','1','-framerate','25','-t',per.toFixed(3),'-i',img);
  }
  args.push('-i', audioPath);
  args.push('-loop','1','-framerate','25','-t',totalDur.toFixed(3),'-i',overlayPath);

  const parts = images.map((image, i) =>
    '[' + i + ':v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30,' +
    (/\.mp4$/i.test(image) ? '' : "zoompan=z='min(zoom+0.00012,1.04)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1080x1920:fps=30,") +
    'setpts=PTS-STARTPTS[v' + i + ']'
  ).join(';');
  const concat = images.map((_, i) => '[v' + i + ']').join('');
  const ovIdx = images.length + 1;
  const assPath = subPath.replace(/\.vtt$/i, '.ass');
  try { if (fs.existsSync(subPath) && fs.statSync(subPath).size > 50) execFileSync('python3', [path.join(__dirname, 'vtt-to-karaoke.py'), subPath, assPath], { timeout: 60000, stdio: 'pipe' }); } catch (e) { console.log('   ⚠️  karaoke convert failed: ' + e.message); }
  const hasSubs = fs.existsSync(assPath) && fs.statSync(assPath).size > 50;
  if (!hasSubs) throw new Error('Caption burn-in required');
  const subStep = hasSubs
    ? ';[withov]subtitles=filename=' + assPath.replace(/([:\\'])/g, '\\$1') +
      ':fontsdir=' + path.resolve(__dirname,'../../frontend/public/fonts').replace(/([:\\'])/g, '\\$1') + "[outv]"
    : ';[withov]null[outv]';

  const filter = parts + ';' + concat + 'concat=n=' + images.length + ':v=1:a=0[base];' +
    '[base][' + ovIdx + ':v]overlay=0:0[withov]' + subStep;
  args.push('-filter_complex', filter);
  args.push('-map', '[outv]', '-map', images.length + ':a');
  args.push('-af', 'loudnorm=I=-14:TP=-1.5:LRA=11,apad=pad_dur=1.25');
  args.push('-t', totalDur.toFixed(2));
  args.push('-c:v', 'libx264', '-preset', process.env.VIDEO_PRESET || 'medium', '-crf', '20', '-threads', '2');
  args.push('-pix_fmt', 'yuv420p', '-movflags', '+faststart');
  args.push('-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2', outPath);

  execFileSync('ffmpeg', args, { timeout: 900000, stdio: 'pipe' });
  const renderDur = Number(execFileSync('ffprobe', [
    '-v','error','-show_entries','format=duration',
    '-of','default=noprint_wrappers=1:nokey=1', outPath
  ]).toString().trim());
  if (renderDur + 0.5 < audioDur) throw new Error('Render ' + renderDur + 's < audio ' + audioDur + 's');
  return { audioDur, renderDur };
}


export async function main() {
  if(!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY)throw new Error('Server Supabase credentials required');
  if(fs.existsSync(path.join(TMP,'manifest.json')) || fs.existsSync(path.join(TMP,'claim.json')))throw new Error('Unfinished job exists: recover upload/claim before another render');
  await loadVaultEnv();
  fs.mkdirSync(TMP,{recursive:true});
  const db=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
  const call=async(name,args={})=>{const {data,error}=await db.rpc(name,args);if(error)throw new Error(name+': '+error.message);return data;};
  await call('recover_expired_video_generation_jobs');
  const claims=await call('claim_reviewed_video_job',{p_article_id:process.env.ARTICLE_ID?.trim() || null});
  const claim=claims?.[0];if(!claim){console.log('No eligible reviewed article/budget slot. No TTS or upload attempted.');return;}
  const claimPath=path.join(TMP,'claim.json');
  fs.writeFileSync(claimPath,JSON.stringify(claim),{mode:0o600});
  if(process.env.GITHUB_ACTIONS)console.log('::add-mask::'+claim.claim_token);
  const fenced={p_job_id:claim.job_id,p_claim_token:claim.claim_token};
  const renew=()=>call('heartbeat_reviewed_render',fenced);
  try {
    const {data:article,error}=await db.from('articles').select('*').eq('id',claim.article_id).single();
    if(error)throw new Error('Claimed article lookup failed');
    const mode=process.env.VIDEO_PUBLISH_MODE || 'review';
    assertEditorial(article,mode);
    const evidence=await refreshEvidence(article,mode);
    const brandFree=process.env.VIDEO_BRAND_FREE==='true' || (process.env.VIDEO_DELIVERY_PLATFORMS || '').split(',').map(x=>x.trim()).includes('tiktok');
    const script=buildVoiceScript(article,{brandFree});
    const canonical=String(article.content_bn).normalize('NFC').replace(/\s+/g,' ').trim();
    const content_key=hash(canonical),script_hash=hash(script);
    const {data:recent,error:historyError}=await db.from('video_story_reservations').select('content_text,job_id').order('created_at',{ascending:false}).limit(200);
    if(historyError)throw new Error('Duplicate history unavailable; fail closed');
    if(recent?.some(x=>x.job_id!==claim.job_id && nearDuplicate(x.content_text,canonical)))throw new Error('Near-duplicate story held for editorial review');
    await call('reserve_video_story',{...fenced,p_content_key:content_key,p_script_hash:script_hash,p_content_text:canonical});
    const jobDirectory=path.join(TMP,claim.job_id);fs.mkdirSync(jobDirectory,{recursive:true});
    const media=await collectSceneMedia({article,db,claim,directory:jobDirectory});
    await renew();
    const audio=path.join(jobDirectory,'voice.mp3'),vtt=path.join(jobDirectory,'voice.vtt'),overlay=path.join(jobDirectory,'overlay.png'),video=path.join(jobDirectory,'final_output.mp4');
    const caption=await synthesizeVoice(script,audio,vtt);
    await renew();
    renderOverlay(article.title_bn,overlay,{brandFree});
    const duration=composeVideo(media.map(m=>m.local_path),audio,vtt,overlay,video);
    await renew();
    const visual_fingerprint=fingerprint(video,{samples:6});
    const {data:priorAssets,error:priorError}=await db.from('video_delivery_assets').select('manifest').order('created_at',{ascending:false}).limit(100);
    if(priorError)throw new Error('Visual duplicate history unavailable');
    if(priorAssets?.some(a=>a.manifest?.visual_fingerprint?.frames?.length===6 && compareFingerprint(visual_fingerprint,a.manifest.visual_fingerprint).review_candidate))throw new Error('Perceptual duplicate candidate; editorial review required');
    const manifest={brand_free:brandFree,visual_fingerprint,...claim,video_path:video,audio_duration:duration.audioDur,render_duration:duration.renderDur,size_bytes:fs.statSync(video).size,content_key,script_hash,caption_method:caption.method,evidence,media:media.map(({local_path,...m})=>m),publish_mode:mode,synthetic_realistic:false,generated_at:new Date().toISOString()};
    fs.writeFileSync(path.join(TMP,'manifest.json'),JSON.stringify(manifest,null,2),{mode:0o600});
    console.log('Verified render manifest ready for checksum-gated upload.');
  } catch(error) {
    // Local claim retained for operator recovery; failure is never counted as delivery.
    const failed=await call('fail_video_generation_job',{...fenced,p_reason:'Renderer stopped; inspect local diagnostics'}).catch(()=>false);
    if(failed && !fs.existsSync(path.join(TMP,'manifest.json'))) {
      const failedDir=path.join(TMP,claim.job_id);fs.mkdirSync(failedDir,{recursive:true});
      fs.renameSync(claimPath,path.join(failedDir,'failed-claim.json'));
    }
    throw error;
  }
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error('Render stopped:',error.message);process.exitCode=1;});
