import fs from 'node:fs';
import {Client} from 'pg';
const input=JSON.parse(fs.readFileSync('.tiktok-oauth/tokens.private.json','utf8'));
for(const n of ['TIKTOK_ACCESS_TOKEN','TIKTOK_REFRESH_TOKEN','TIKTOK_OPEN_ID'])if(typeof input[n]!=='string' || !input[n])throw new Error('Private OAuth token output incomplete');
const url=new URL(process.env.SUPABASE_DB_URL);for(const k of ['sslmode','sslcert','sslkey','sslrootcert'])url.searchParams.delete(k);
const ca=process.env.SUPABASE_DB_CA_FILE?fs.readFileSync(process.env.SUPABASE_DB_CA_FILE,'utf8'):undefined;
const db=new Client({connectionString:url.href,ssl:{rejectUnauthorized:true,...(ca?{ca}:{})}});
try {
 await db.connect();await db.query('begin');await db.query('select pg_advisory_xact_lock(73920516)');
 for(const name of ['TIKTOK_ACCESS_TOKEN','TIKTOK_REFRESH_TOKEN','TIKTOK_OPEN_ID']) {
  const {rows}=await db.query("select key_encrypted from public.api_vault where service_name=$1 and environment='prod' for update",[name]);
  let id=rows[0]?.key_encrypted;
  if(id)await db.query('select vault.update_secret($1,$2)',[id,input[name]]);
  else {const result=await db.query('select vault.create_secret($1,$2,$3) as id',[input[name],name,'Explicit creator OAuth consent']);id=result.rows[0].id;}
  await db.query("insert into public.api_vault(service_name,key_encrypted,environment,is_active) values($1,$2,'prod',true) on conflict(service_name,environment) do update set key_encrypted=excluded.key_encrypted,is_active=true,updated_at=now()",[name,id]);
 }
 await db.query('commit');console.log('Three TikTok OAuth variables stored in Vault; no values printed. Delete the local private token file after verifying readiness.');
} catch(e){await db.query('rollback').catch(()=>{});console.error('Vault import failed:',e.code || 'configuration');process.exitCode=1;}
finally{await db.end().catch(()=>{});}
