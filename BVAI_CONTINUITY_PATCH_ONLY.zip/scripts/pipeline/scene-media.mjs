// Only explicitly curated Commons file titles, not unrelated category stock footage.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {boundedFetch} from './source-evidence.mjs';
export function commonsMetadata(info) {
  const text=x=>String(x || '').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
  const meta=info.extmetadata || {};
  const license=text(meta.LicenseShortName?.value),author=text(meta.Artist?.value);
  const license_url=text(meta.LicenseUrl?.value);
  if(!/^(CC0(?: 1\.0)?|Public domain|CC BY(?:-SA)? [234]\.0)$/i.test(license))throw new Error('Unsupported or unknown Commons license');
  if(!author || !license_url.startsWith('https://') || !info.descriptionurl?.startsWith('https://commons.wikimedia.org/'))throw new Error('Attribution metadata incomplete');
  const url=info.thumburl || info.url;
  if(new URL(url).hostname!=='upload.wikimedia.org' || !/^image\/(jpeg|png|webp)$/.test(info.mime || ''))throw new Error('Unsupported Commons media type/host');
  return {url,author,license,license_url,source_url:info.descriptionurl,commons_sha1:info.sha1,fetched_at:new Date().toISOString(),illustrative:true};
}
export async function collectSceneMedia({article,db,claim,directory}) {
  let plan=(article.context_blocks || []).filter(x=>x?.commons_title && x?.scene_relevance_reviewed===true);
  if(process.env.VIDEO_SCENE_PLAN_FILE) {
    const plans=JSON.parse(fs.readFileSync(process.env.VIDEO_SCENE_PLAN_FILE,'utf8'));
    plan=plans[article.id] || [];
  }
  if(!Array.isArray(plan) || plan.length<3 || plan.length>8 || plan.some(x=>x.scene_relevance_reviewed!==true))throw new Error('Provide 3–8 editor-reviewed Commons scenes in context_blocks or VIDEO_SCENE_PLAN_FILE');
  const media=[];const seen=new Set();
  for(const scene of plan) {
    if(!/^File:[^|\r\n]{1,240}$/.test(scene.commons_title || ''))throw new Error('Explicit Commons File title required');
    const api=new URL('https://commons.wikimedia.org/w/api.php');
    api.search=new URLSearchParams({action:'query',format:'json',formatversion:'2',prop:'imageinfo',titles:scene.commons_title,iiprop:'url|sha1|mime|extmetadata',iiurlwidth:'1280',maxlag:'5'});
    const response=await boundedFetch(api.href);
    const data=JSON.parse(response.bytes);if(data.error)throw new Error('Commons temporarily unavailable');
    const info=data.query?.pages?.[0]?.imageinfo?.[0];if(!info)throw new Error('Commons file missing');
    const m=commonsMetadata(info);
    const image=await boundedFetch(m.url,{maxBytes:15*1024*1024});
    const sha256=createHash('sha256').update(image.bytes).digest('hex');
    if(seen.has(sha256))throw new Error('Repeated scene within render');seen.add(sha256);
    const {error}=await db.rpc('reserve_video_visual',{p_job_id:claim.job_id,p_claim_token:claim.claim_token,p_sha256:sha256,p_source_url:m.source_url});
    if(error)throw new Error('Scene already used or reservation unavailable');
    const local_path=path.join(directory,`scene-${media.length}.`+(info.mime==='image/png'?'png':info.mime==='image/webp'?'webp':'jpg'));
    fs.writeFileSync(local_path,image.bytes,{mode:0o600});
    media.push({...m,sha256,local_path});
  }
  return media;
}
