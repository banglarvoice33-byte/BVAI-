import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {buildVoiceScript} from '../generate-video.js';
import {assertTiktokApproval,deliverTiktok} from '../delivery-providers.mjs';
import {commonsMetadata} from '../scene-media.mjs';
import {assertEditorial,isNewsUrl} from '../source-evidence.mjs';
const root=new URL('../../../',import.meta.url);
test('All active entrypoints resolve ESM imports without starting network work',()=>{
 for(const file of ['generate-video.js','upload-supabase-video.mjs','delivery-worker.mjs']) {
  execFileSync(process.execPath,['--input-type=module','-e',`await import(${JSON.stringify(new URL('../'+file,import.meta.url).href)})`],{timeout:15000});
 }
});
test('Narration has no invented incident date, emotion or consequences',()=>{
 const s=buildVoiceScript({title_bn:'সেতু চালু',content_bn:'কর্তৃপক্ষ আজ নতুন সেতু চালু করেছে। সেতুতে 20টি বাস চলছে।'});
 assert.match(s,/২০টি/);assert.doesNotMatch(s,/আনন্দ ছড়িয়ে|পরিস্থিতি আরও জটিল|আজ [০-৯]/);
});
test('Encyclopedia cannot count as a second independent breaking-news source',()=>{
 assert.equal(isNewsUrl('https://bn.wikipedia.org/wiki/News'),false);
 assert.throws(()=>assertEditorial({status:'published',human_verified:true,verification_status:'verified',source_published_at:new Date().toISOString(),content_bn:'বিশ্বস্ত সংবাদ যাচাই করা জরুরি। '.repeat(8),source_url:'https://news.example/story',fact_sources:['https://bn.wikipedia.org/wiki/Test']},'website'),/two source/);
});
test('Commons metadata must include supported reusable rights, artist, license URL and trusted media host',()=>{
 const good={url:'https://upload.wikimedia.org/example.jpg',descriptionurl:'https://commons.wikimedia.org/wiki/File:Example.jpg',mime:'image/jpeg',extmetadata:{LicenseShortName:{value:'CC BY-SA 4.0'},LicenseUrl:{value:'https://creativecommons.org/licenses/by-sa/4.0/'},Artist:{value:'Example photographer'}}};
 assert.equal(commonsMetadata(good).author,'Example photographer');
 assert.throws(()=>commonsMetadata({...good,extmetadata:{...good.extmetadata,LicenseShortName:{value:'All rights reserved'}}}),/license/);
 assert.throws(()=>commonsMetadata({...good,url:'https://evil.example/a.jpg'}),/host/);
});
const hash='a'.repeat(64);
const approval={video_sha256:hash,open_id:'account',reviewer_id:'editor',explicit_upload_consent:true,music_usage_confirmed:true,no_promotional_watermark:true,app_use_case_approved:true,approved_at:new Date().toISOString(),privacy:'SELF_ONLY',verified_url_prefix:'https://media.example/reels/',title:'Editable reviewed title with source credits',allow_comment:false,allow_duet:false,allow_stitch:false};
test('TikTok never assumes consent/privacy from environment or email',()=>{
 assert.throws(()=>assertTiktokApproval({videoSha256:hash,openId:'account',mediaUrl:'https://media.example/reels/a.mp4'}),/approval/);
 assert.throws(()=>assertTiktokApproval({approval,videoSha256:hash,openId:'account',mediaUrl:'https://media.example/reels/a.mp4'}),/privacy/);
 assert.doesNotThrow(()=>assertTiktokApproval({approval,videoSha256:hash,openId:'account',mediaUrl:'https://media.example/reels/a.mp4',privacy:'SELF_ONLY'}));
 assert.throws(()=>assertTiktokApproval({approval,videoSha256:hash,openId:'account',mediaUrl:'https://media.example/reels-evil/a.mp4',privacy:'SELF_ONLY'}),/prefix/);
});
test('TikTok processing checkpoint is polled without init, consent bypass, or duplicate upload',async()=>{
 const old=globalThis.fetch;let posts=0;
 try {
  globalThis.fetch=async(url,opts)=>{assert.match(String(url),/status\/fetch/);posts++;return new Response(JSON.stringify({error:{code:'ok'},data:{status:'PUBLISH_COMPLETE',publicaly_available_post_id:['post-id']}}));};
  const result=await deliverTiktok({token:'offline',checkpoint:{publish_id:'same-session',requested_privacy:'PUBLIC_TO_EVERYONE'},save:async()=>{}});
  assert.equal(result.id,'post-id');assert.equal(posts,1);
 }finally{globalThis.fetch=old;}
});
test('TikTok HTTP 200 business error is not a successful post receipt',async()=>{
 const old=globalThis.fetch;
 try {globalThis.fetch=async()=>new Response(JSON.stringify({error:{code:'access_token_invalid'}}));
 await assert.rejects(()=>deliverTiktok({token:'offline',checkpoint:{publish_id:'same-session'},save:async()=>{}}),/access_token_invalid/);
 }finally{globalThis.fetch=old;}
});
test('Root locked installs, five build entries and TikTok verification asset exist',()=>{
 assert.ok(fs.existsSync(new URL('package-lock.json',root)));
 const build=fs.readFileSync(new URL('.github/workflows/mobile-five-apps.yml',root),'utf8');
 for(const name of ['reader','reporter','admin','studio','tv'])assert.match(build,new RegExp(name));
 assert.equal(fs.readFileSync(new URL('frontend/public/tiktokqG70EYtoSlqkGv0XPQc7b8G1GPgrZYYN.txt',root),'utf8').trim(),'tiktok-developers-site-verification=qG70EYtoSlqkGv0XPQc7b8G1GPgrZYYN');
});

test('TikTok clean-master narration excludes promotional CTA',()=>{
 const s=buildVoiceScript({title_bn:'সেতু চালু',content_bn:'নতুন সেতু চালু হয়েছে। সেতুতে বাস চলছে।'},{brandFree:true});
 assert.doesNotMatch(s,/বাংলার ভয়েস|ওয়েবসাইটে/);
});
