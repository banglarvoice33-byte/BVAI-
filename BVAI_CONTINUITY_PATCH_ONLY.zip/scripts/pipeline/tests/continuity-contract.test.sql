-- Isolated local database ONLY. All fixtures rolled back; no actual HTTP request.
BEGIN;
CREATE SCHEMA IF NOT EXISTS vault;
CREATE TABLE IF NOT EXISTS vault.decrypted_secrets(id uuid,decrypted_secret text);
CREATE TABLE IF NOT EXISTS public.api_vault(service_name text,key_encrypted uuid,environment text,is_active boolean);
CREATE SCHEMA IF NOT EXISTS net;
CREATE OR REPLACE FUNCTION public.deployment_setting(text) RETURNS text LANGUAGE sql AS $$ SELECT 'https://test.example'::text $$;
CREATE OR REPLACE FUNCTION net.http_post(url text,headers jsonb,body jsonb,timeout_milliseconds integer) RETURNS bigint LANGUAGE sql AS $$ SELECT 123456::bigint $$;
INSERT INTO vault.decrypted_secrets VALUES('11111111-1111-1111-1111-111111111111',repeat('x',40));
INSERT INTO public.api_vault VALUES('NEWSROOM_INGEST_KEY','11111111-1111-1111-1111-111111111111','prod',true);
DO $$ DECLARE req bigint; article uuid:=gen_random_uuid(); j uuid; token uuid; BEGIN
 req:=public.tick_newsroom_14m();IF req<>123456 THEN RAISE EXCEPTION 'TEST cadence did not enqueue'; END IF;
 IF public.tick_newsroom_14m() IS NOT NULL THEN RAISE EXCEPTION 'TEST immediate duplicate tick'; END IF;
 UPDATE public.newsroom_cadence_state SET last_requested_at=now()-interval '13 minutes 59 seconds';
 IF public.tick_newsroom_14m() IS NOT NULL THEN RAISE EXCEPTION 'TEST early tick'; END IF;
 UPDATE public.newsroom_cadence_state SET last_requested_at=now()-interval '14 minutes';
 IF public.tick_newsroom_14m()<>123456 THEN RAISE EXCEPTION 'TEST 14m tick missing'; END IF;
 INSERT INTO public.articles(id,title_bn,content_bn,status,published_at,human_verified,verification_status,source_published_at) VALUES(article,'পরীক্ষা',repeat('বাংলা সংবাদ ',40),'published',now(),true,'verified',now());
 SELECT job_id,claim_token INTO j,token FROM public.claim_reviewed_video_job(article);
 IF public.heartbeat_reviewed_render(j,token) IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST heartbeat failed'; END IF;
 BEGIN
 PERFORM public.heartbeat_reviewed_render(j,gen_random_uuid());RAISE EXCEPTION 'TEST invalid heartbeat accepted';
 EXCEPTION WHEN OTHERS THEN IF SQLERRM='TEST invalid heartbeat accepted' THEN RAISE; END IF; END;
 UPDATE public.video_generation_jobs SET lease_expires_at=now()-interval '1 second' WHERE id=j;
 BEGIN
 PERFORM public.heartbeat_reviewed_render(j,token);RAISE EXCEPTION 'TEST expired fence renewed';
 EXCEPTION WHEN OTHERS THEN IF SQLERRM='TEST expired fence renewed' THEN RAISE; END IF; END;
 RAISE NOTICE 'PASS: 14-minute elapsed gate, no early/duplicate ticks, valid render heartbeat, expired/wrong fences denied';
END $$;
SET LOCAL ROLE anon;
DO $$ BEGIN
 BEGIN PERFORM public.tick_newsroom_14m();RAISE EXCEPTION 'TEST anon cadence executed';EXCEPTION WHEN insufficient_privilege THEN NULL;END;
 BEGIN PERFORM public.heartbeat_reviewed_render(gen_random_uuid(),gen_random_uuid());RAISE EXCEPTION 'TEST anon heartbeat executed';EXCEPTION WHEN insufficient_privilege THEN NULL;END;
 RAISE NOTICE 'PASS: new scheduler/heartbeat RPCs deny anonymous execution';
END $$;
ROLLBACK;
