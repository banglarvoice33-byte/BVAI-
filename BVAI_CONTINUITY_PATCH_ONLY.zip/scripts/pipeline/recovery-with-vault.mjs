import {loadVaultEnv} from './load-vault-env.mjs';
await loadVaultEnv(['VIDEO_RECOVERY_KEY']);
if(!process.env.VIDEO_RECOVERY_KEY)throw new Error('Recovery encryption key missing; secret-bearing state will NOT be uploaded');
await import('./protect-recovery.mjs');
