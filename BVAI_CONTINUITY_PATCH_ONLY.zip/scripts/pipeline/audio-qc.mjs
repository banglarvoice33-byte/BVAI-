import {spawnSync} from 'node:child_process';
export function measureAudio(filename) {
  const result=spawnSync('ffmpeg',['-hide_banner','-nostdin','-i',filename,'-vn','-af','loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json','-f','null','-'],{encoding:'utf8',timeout:180000,maxBuffer:2*1024*1024});
  if(result.status!==0)throw new Error('Audio analysis failed');
  const match=result.stderr.match(/\{\s*"input_i"[\s\S]*?\}/);
  if(!match)throw new Error('Missing loudness measurement');
  const data=JSON.parse(match[0]);
  if(![data.input_i,data.input_tp,data.input_lra].every(x=>Number.isFinite(Number(x))))throw new Error('Silence/invalid audio loudness');
  return data;
}
