import fs from 'node:fs';
import {Client} from 'pg';
const files={'--activate-articles':'enable-14-minute-cadence.sql','--rollback-articles':'rollback-14-minute-cadence.sql'};
const file=files[process.argv[2]];if(!file)throw new Error('Invalid action');
if(process.env.BVAI_LIVE_CANARY_CONFIRMED!=='YES')throw new Error('Set BVAI_LIVE_CANARY_CONFIRMED=YES only after verifying live authenticated web invocation');
const u=new URL(process.env.SUPABASE_DB_URL);for(const k of ['sslmode','sslcert','sslkey','sslrootcert'])u.searchParams.delete(k);
const ca=process.env.SUPABASE_DB_CA_FILE?fs.readFileSync(process.env.SUPABASE_DB_CA_FILE,'utf8'):undefined;
const db=new Client({connectionString:u.href,ssl:{rejectUnauthorized:true,...(ca?{ca}:{})}});
try{await db.connect();await db.query(fs.readFileSync(new URL('../deploy/'+file,import.meta.url),'utf8'));console.log('Scheduler action committed; inspect cron and publication receipts.');}
catch(e){await db.query('rollback').catch(()=>{});console.error('Scheduler action failed:',e.code || 'configuration');process.exitCode=1;}
finally{await db.end().catch(()=>{});}
