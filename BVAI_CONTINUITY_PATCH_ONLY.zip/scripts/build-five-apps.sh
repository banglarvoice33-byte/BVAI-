#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${MOBILE_BUILD_CONFIG:?Point to a private JSON dart-define config; never use service-role keys}"
[[ "$CONFIG" = /* ]] || CONFIG="$PWD/$CONFIG"
command -v flutter >/dev/null || { echo 'Flutter SDK and Android SDK required; run on Android CI, not native Termux'; exit 1; }
node "$ROOT/scripts/validate-mobile-config.mjs" "$CONFIG"
: "${MOBILE_BUILD_NUMBER:?Use a monotonically increasing Android build number}"
[[ "$MOBILE_BUILD_NUMBER" =~ ^[1-9][0-9]*$ ]] || exit 1
mkdir -p "$ROOT/artifacts/mobile"
for app in reader reporter admin studio tv; do
 dir="$ROOT/mobile_monorepo/apps/${app}_app"
 [[ -f "$dir/android/key.properties" ]] || { echo "Release signing missing for $app; no unsigned substitute"; exit 1; }
 target="lib/main_${app}.dart"; [[ "$app" == reader ]] && target='lib/main.dart'
 (cd "$dir" && flutter pub get && flutter analyze --no-fatal-infos && flutter build apk --release -t "$target" --build-number="$MOBILE_BUILD_NUMBER" --dart-define-from-file="$CONFIG")
 cp "$dir/build/app/outputs/flutter-apk/app-release.apk" "$ROOT/artifacts/mobile/banglarvoice-${app}.apk"
done
(cd "$ROOT/artifacts/mobile" && sha256sum ./*.apk > SHA256SUMS.txt)
echo 'Five signed APK artifacts and checksums created in artifacts/mobile'
