// Idempotent, advisory-locked patch deployment. Default: read-only contract check.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {Client} from 'pg';
const raw=process.env.SUPABASE_DB_URL;if(!raw)throw new Error('SUPABASE_DB_URL required');
const url=new URL(raw);for(const k of ['sslmode','sslcert','sslkey','sslrootcert'])url.searchParams.delete(k);
const ca=process.env.SUPABASE_DB_CA_FILE?fs.readFileSync(process.env.SUPABASE_DB_CA_FILE,'utf8'):undefined;
const db=new Client({connectionString:url.href,ssl:{rejectUnauthorized:true,...(ca?{ca}:{})},connectionTimeoutMillis:15000});
try {
 await db.connect();
 const {rows:[contract]}=await db.query(`select
 to_regprocedure('public.finalize_website_video(uuid,uuid,uuid,text,text,integer,text,bigint,boolean)') is not null as baseline,
 to_regclass('public.api_vault') is not null as vault_index,
 to_regclass('public.video_delivery_outbox') is not null as outbox,
 to_regprocedure('public.heartbeat_reviewed_render(uuid,uuid)') is not null as new_heartbeat`);
 console.log(JSON.stringify(contract));if(!contract.baseline || !contract.vault_index)throw new Error('Missing prerequisite; do not replay historic migrations blindly');
 if(process.argv.includes('--apply')) {
  await db.query('select pg_advisory_lock(73920515)');
  await db.query(`create table if not exists public.bvai_patch_history(name text primary key,sha256 text not null,applied_at timestamptz not null default now());
   alter table public.bvai_patch_history enable row level security;
   revoke all on public.bvai_patch_history from public,anon,authenticated; grant select on public.bvai_patch_history to service_role;`);
  const files=['20261110000000_media_delivery_reliability.sql','20261110010000_tiktok_outbox_platform.sql','20261110010001_media_observability.sql','20261110020000_execution_continuity_patch.sql'];
  for(const name of files) {
   const sql=fs.readFileSync(new URL('../supabase/migrations/'+name,import.meta.url),'utf8');
   const hash=createHash('sha256').update(sql).digest('hex');
   const {rows}=await db.query('select sha256 from public.bvai_patch_history where name=$1',[name]);
   if(rows.length){if(rows[0].sha256!==hash)throw new Error('Previously applied patch checksum changed');console.log('Already applied: '+name);continue;}
   // Each file contains BEGIN/COMMIT; append history inside the same transaction.
   const end=sql.lastIndexOf('COMMIT;');if(end<0)throw new Error('Migration transaction boundary missing');
   await db.query(sql.slice(0,end));
   await db.query('insert into public.bvai_patch_history(name,sha256) values($1,$2)',[name,hash]);
   await db.query('COMMIT');
   console.log('Applied: '+name);
  }
  await db.query('select pg_advisory_unlock(73920515)');
  console.log('Patch committed. Existing automation preserved; new 14m cadence inactive until explicit cutover.');
 }
} catch(error){await db.query('ROLLBACK').catch(()=>{});console.error('Patch stopped:',error.code || error.message);process.exitCode=1;}
finally{await db.end().catch(()=>{});}
