// Operator-run bridge: only two bootstrap secrets leave Vault boundary for Actions.
import {spawnSync} from 'node:child_process';
const repo=process.argv.find(x=>x.startsWith('--repo='))?.slice(7);
if(!repo || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo))throw new Error('Use --repo=OWNER/REPO');
const apply=process.argv.includes('--apply'),enable=process.argv.includes('--enable-video');
if(enable && process.env.BVAI_LIVE_CANARY_CONFIRMED!=='YES')throw new Error('Run a reviewed live canary before enabling video automation');
for(const name of ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY'])if(!process.env[name])throw new Error('Missing '+name);
function gh(args,input){const p=spawnSync('gh',args,{input,encoding:'utf8',stdio:['pipe','pipe','pipe']});if(p.status!==0)throw new Error('GitHub CLI action failed; check gh auth status and repository access');}
for(const name of ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY']) {
 console.log((apply?'Setting secret: ':'Would set secret: ')+name);
 if(apply)gh(['secret','set',name,'--repo',repo],process.env[name]);
}
const vars={VIDEO_PUBLISH_MODE:process.env.VIDEO_PUBLISH_MODE || 'review',VIDEO_DELIVERY_PLATFORMS:process.env.VIDEO_DELIVERY_PLATFORMS || 'youtube',YOUTUBE_PRIVACY:process.env.YOUTUBE_PRIVACY || 'unlisted',VIDEO_DISTRIBUTION_WORKER_ENABLED:'false'};
if(enable){vars.ENABLE_VIDEO_AUTOMATION='true';vars.VIDEO_DELIVERY_ENABLED='true';}
for(const name of ['YOUTUBE_CHANNEL_ID','VIDEO_SCENE_PLAN_FILE','SOCIAL_FACEBOOK_PAGE_ID','SOCIAL_INSTAGRAM_BUSINESS_ACCOUNT_ID','TIKTOK_OPEN_ID','FACEBOOK_GRAPH_VERSION'])if(process.env[name])vars[name]=process.env[name];
for(const [name,value] of Object.entries(vars)){console.log((apply?'Setting variable: ':'Would set variable: ')+name);if(apply)gh(['variable','set',name,'--repo',repo,'--body',value]);}
console.log(apply?'Actions configuration applied; inspect real provider receipts, not scheduler status.':'Dry run only. Use --apply after gh auth login. No account was changed.');
