import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import {editorialContext,EditorialAuthError} from '@/lib/server/editorial-context';

export const revalidate = 0;
export const dynamic = 'force-dynamic';

function getAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Supabase admin creds missing');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export async function POST(req: Request) {
  try {
    const {session} = await editorialContext(req);
    if (Number(req.headers.get('content-length') || 0) > 16384) return NextResponse.json({error:'instruction_too_large'},{status:413});
    const text = await req.text();
    if (text.length > 16384) return NextResponse.json({error:'instruction_too_large'},{status:413});
    const { id, note } = JSON.parse(text);
    if (!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id || '')) return NextResponse.json({ error: 'id required' }, { status: 400 });

    const supabase = getAdmin();
    const { data, error } = await session.rpc('approve_reporter_article', {p_article_id:id,p_note:typeof note==='string'?note.slice(0,4000):''}).maybeSingle<{id:string;status:string;published_at:string}>();

    if (error) throw error;
    if (!data) return NextResponse.json({ error: 'not found or not pending' }, { status: 404 });

    // Field-report articles: publish the reporter's photo. The upload sits in the
    // private `field-media` bucket; copy it to the public `thumbnails` bucket.
    // A media problem must never block the approval itself.
    let featuredImage: string | null = null;
    try {
      const { data: art } = await supabase
        .from('articles')
        .select('field_report_id, featured_image')
        .eq('id', id)
        .maybeSingle();
      if (art?.field_report_id && !art.featured_image) {
        const { data: rep } = await supabase
          .from('field_reports')
          .select('media_urls')
          .eq('id', art.field_report_id)
          .maybeSingle();
        const src = ((rep?.media_urls as string[] | null) ?? []).find((p) =>
          /\.(jpe?g|png|webp)$/i.test(p),
        );
        if (src) {
          const dl = await supabase.storage.from('field-media').download(src);
          if (dl.data) {
            const ext = (src.split('.').pop() || 'jpg').toLowerCase();
            const dest = `field-reports/${art.field_report_id}.${ext}`;
            const contentType =
              ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
            const up = await supabase.storage
              .from('thumbnails')
              .upload(dest, dl.data, { contentType, upsert: true });
            if (!up.error) {
              const pub = supabase.storage.from('thumbnails').getPublicUrl(dest).data.publicUrl;
              await session
                .from('articles')
                .update({ featured_image: pub, thumbnail_url: pub, media_type: 'image' })
                .eq('id', id);
              featuredImage = pub;
            }
          }
        }
      }
    } catch (mediaErr) {
      console.error('[approve] field-report media copy failed', mediaErr);
    }

    return NextResponse.json(
      { ok: true, id: data.id, status: data.status, published_at: data.published_at, note: note || '', featured_image: featuredImage },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (e) {
    if(e instanceof EditorialAuthError)return NextResponse.json({error:e.message},{status:e.status});
    return NextResponse.json(
      { error: 'editorial_approval_unavailable' },
      { status: 500 },
    );
  }
}
