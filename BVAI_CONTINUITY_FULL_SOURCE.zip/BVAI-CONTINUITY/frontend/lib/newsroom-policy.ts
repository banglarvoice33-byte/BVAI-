export const MAX_PUBLISH_PER_RUN = 1
export const MIN_PUBLISH_PER_RUN = 1
export const MAX_CANDIDATES_PER_RUN = 6
export const MAX_SOURCES_PER_RUN = 8
export const PRIORITY_CANDIDATE_TARGET_PERCENT = 70

export const WORLD_CLASS_FEED_HOSTS = [
  'feeds.bbci.co.uk',
  'bbc.co.uk',
  'bbc.com',
  'reuters.com',
  'apnews.com',
  'nytimes.com',
  'theguardian.com',
  'aljazeera.com',
  'npr.org',
  'dw.com',
  'france24.com',
  'thehindu.com',
  'japantimes.co.jp',
  'afp.com',
]

const WORLD_CLASS_NAME_HINTS = [
  'bbc',
  'reuters',
  'associated press',
  'ap news',
  'new york times',
  'nytimes',
  'guardian',
  'al jazeera',
  'npr',
  'deutsche welle',
  'dw ',
  'france 24',
  'the hindu',
  'japan times',
  'afp',
]

export function isWorldClassFeed(feedUrl: string, sourceName = ''): boolean {
  const host = feedUrl.toLowerCase()
  if (WORLD_CLASS_FEED_HOSTS.some((item) => host.includes(item))) return true
  const name = sourceName.toLowerCase()
  return WORLD_CLASS_NAME_HINTS.some((hint) => name.includes(hint.trim()))
}

export function rankSourcesForRun<T extends { feed_url: string; name?: string; last_probe_at?: string | null }>(
  sources: T[],
  limit = MAX_SOURCES_PER_RUN,
): T[] {
  const worldClass = sources.filter((source) => isWorldClassFeed(source.feed_url, source.name || ''))
  const others = sources.filter((source) => !isWorldClassFeed(source.feed_url, source.name || ''))
  const byOldestProbe = (left: T, right: T) =>
    Date.parse(left.last_probe_at || '1970-01-01') - Date.parse(right.last_probe_at || '1970-01-01')
  const count = Math.max(1, limit)
  const preferred = worldClass.sort(byOldestProbe)
  const general = others.sort(byOldestProbe)
  // Reserve at least one rotating non-preferred source when available.
  const primary = preferred.slice(0, general.length ? Math.max(0, count - 1) : count)
  const reserved = general.slice(0, general.length ? 1 : 0)
  const remaining = [...preferred.slice(primary.length), ...general.slice(reserved.length)].sort(byOldestProbe)
  return [...primary, ...reserved, ...remaining].slice(0, count)
}
