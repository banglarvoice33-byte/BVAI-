-- Run only after backup, web deploy and authenticated live canary pass.
-- The pg_cron tick owns article invocation; do not run a second writer cron/continuous writer.
BEGIN;
DO $$ DECLARE target bigint; current_enabled boolean; BEGIN
 SELECT jobid,active INTO target,current_enabled FROM cron.job WHERE jobname='bvai-newsroom-14m';
 IF target IS NULL THEN RAISE EXCEPTION 'Apply execution continuity migration first'; END IF;
 IF current_enabled THEN RETURN; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.api_vault v JOIN vault.decrypted_secrets s ON s.id=v.key_encrypted WHERE v.service_name='NEWSROOM_INGEST_KEY' AND v.environment='prod' AND v.is_active AND length(s.decrypted_secret)>=32) THEN RAISE EXCEPTION 'Ingest Vault credential missing'; END IF;
 UPDATE public.newsroom_cadence_state SET previous_jobs=COALESCE((SELECT jsonb_agg(jsonb_build_object('jobname',jobname,'active',active,'schedule',schedule)) FROM cron.job WHERE jobname IN ('news-ingest-daytime','news-ingest-overnight','news-ingest-5min','newsroom-failed-retry')), '[]'::jsonb) WHERE id=true;
 UPDATE cron.job SET active=false WHERE jobname IN ('news-ingest-daytime','news-ingest-overnight','news-ingest-5min','newsroom-failed-retry');
 PERFORM cron.alter_job(target,active:=true);
END $$;
COMMIT;
