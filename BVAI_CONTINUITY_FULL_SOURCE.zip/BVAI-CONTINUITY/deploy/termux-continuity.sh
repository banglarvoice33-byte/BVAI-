#!/usr/bin/env bash
# No cloud credentials embedded. No secrets sourced as shell code. No auto-publication.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
MODE="${1:---check}"
case "$MODE" in --check|--apply|--activate-articles|--rollback-articles) ;; *) echo 'Use --check / --apply / --activate-articles / --rollback-articles'; exit 2;; esac
command -v node >/dev/null || { echo 'Install nodejs-lts in Termux first'; exit 1; }
[[ -f .env ]] || { echo 'Create private .env with Supabase server credentials'; exit 1; }
chmod 600 .env
npm ci --no-audit --no-fund
node --test scripts/pipeline/tests/*.test.mjs
if [[ "$MODE" == --check ]]; then
 node --env-file=.env scripts/apply-continuity-patch.mjs
 node --env-file=.env scripts/pipeline/readiness.mjs
elif [[ "$MODE" == --apply ]]; then
 [[ "${BVAI_BACKUP_CONFIRMED:-}" == YES ]] || { echo 'Take and verify DB backup, then set BVAI_BACKUP_CONFIRMED=YES'; exit 1; }
 node --env-file=.env scripts/apply-continuity-patch.mjs --apply
else
 node --env-file=.env scripts/run-scheduler-sql.mjs "$MODE"
fi
