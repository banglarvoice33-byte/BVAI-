-- Non-destructive scheduler rollback only. Never delete media/outbox tables.
BEGIN;
UPDATE cron.job SET active=false WHERE jobname='bvai-newsroom-14m';
DO $$ DECLARE item jsonb; job bigint; BEGIN
 FOR item IN SELECT value FROM public.newsroom_cadence_state,jsonb_array_elements(previous_jobs) WHERE id=true LOOP
  SELECT jobid INTO job FROM cron.job WHERE jobname=item->>'jobname';
  IF job IS NOT NULL THEN PERFORM cron.alter_job(job,schedule:=item->>'schedule',active:=(item->>'active')::boolean); END IF;
 END LOOP;
END $$;
COMMIT;
